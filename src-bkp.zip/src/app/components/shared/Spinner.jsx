import React from "react";

export default function Spinner() {
  return (
    <div>
      <div className="spinner-wrapper">
        <div className="donut"></div>
      </div>
    </div>
  );
}
