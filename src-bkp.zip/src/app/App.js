import React from "react";
import "./App.scss";
import AppRoutes from "./routes";
import Navbar from "../app/components/shared/Navbar";
import Sidebar from "../app/components/shared/Sidebar";
import Footer from "../app/components/shared/Footer";

function App() {
  let navbarComponent = <Navbar />;
  let sidebarComponent = <Sidebar />;
  let footerComponent = <Footer />;
  return (
    <div className="container-scroller">
      <AppRoutes />
    </div>
  );
}

export default App;
